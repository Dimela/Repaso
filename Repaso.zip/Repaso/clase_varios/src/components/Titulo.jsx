// eslint-disable-next-line no-unused-vars
import React, { Fragment } from 'react'
import Subtitulo from './Subtitulo'
const Titulo = () => {
    const pagina = 3
    const paginanueva= 45

  return (
    <>
    <h1 className='titulo'>Bienvenidos a la clase 3</h1> 
    <Subtitulo
        className="sub"
        info1="Clase de Componente"
        pagina={pagina}
    />
    <Subtitulo
        info2="Clase de Props"
        pagina={paginanueva}
    />
    </>
  )
}

export default Titulo
