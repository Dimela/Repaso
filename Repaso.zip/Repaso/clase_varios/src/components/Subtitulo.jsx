// eslint-disable-next-line no-unused-vars
import React from 'react'

// eslint-disable-next-line react/prop-types
const Subtitulo = ({info1, info2, pagina}) => {
  return (
    <>
    <h2>{info1}</h2>
    <h2>{info2}</h2>
    <p>{pagina}</p>
    </>
  )
}

export default Subtitulo
