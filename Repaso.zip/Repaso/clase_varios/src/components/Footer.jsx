// eslint-disable-next-line no-unused-vars
import React from 'react'

const Footer = () => {
  return (
    <footer>Todos los derechos reservados a los alumnos de FF3</footer>
  )
}

export default Footer
