// eslint-disable-next-line no-unused-vars
import React from 'react'

const Objeto = () => {

    const productos = [
        {
            id: 32312,
            nombre: "Memoria Ram 16gb",
            precio: 300
        },
        {
            id: 4343,
            nombre: "teclado",
            precio: 20
        },
        {
            id: 545,
            nombre: "Placa de Video ",
            precio: 500
        },
        {
            id: 43242,
            nombre: "Monitor",
            precio: 200
        }
    ]
  return (
    <>
        <h3>Map de Objeto</h3>
        <ol>
            {productos.map((elemento)=>{
                return(
                    // eslint-disable-next-line react/jsx-key
                    <li
                        key={elemento.id}
                    >
                        Producto: {elemento.nombre} - Preio: {elemento.precio}
                    </li>
                )
            })}
        </ol>
    
    </>
  )
}
export default Objeto
